# DO NOT USE IF YOU HAVE IMPORTANT SAVE FILES
# REPORT ANY ISSUES TO @Giraffe#1234

import os
import pyautogui as pag
import time
import keyboard as kb
import shutil
import tkinter as tk
from tkinter import simpledialog


# MODIFY THESE VARIABLES
savestate_load_hotkey = "U"  # Key used to load a savestate
savestate_create_hotkey = "O"  # Key used to create a savestate
savestate_switch_hotkey = "N"  # Key used to switch active savestate
monitor_resolution = (2560, 1440)  # Resolution of monitor used for the game. EX. (1920, 1080), (2560, 1440), (3840, 2160)
load_delay_seconds = 1  # Time before inputs during load screens, increase if inputs occur during loads
menu_delay_seconds = 0.1  # Time before inputs in menus, increase if inputs do not occur after pausing or if incorrect inputs occur
game_window_name = "Slime Rancher"  # Name of game window, change if name is custom
saves_directory_path = os.path.expanduser('~') + "\\AppData\\LocalLow\\Monomi Park\\Slime Rancher"  # Path of saves folder, Windows only

# DO NOT MODIFY
new_game_pos = (monitor_resolution[0]/2, monitor_resolution[1]*.58)
confirm_pos = (monitor_resolution[0]*.56, monitor_resolution[1]*.83)
save_and_quit_pos = (monitor_resolution[0]/2, monitor_resolution[1]*.77)
continue_pos = (monitor_resolution[0]/2, monitor_resolution[1]*.44)
load_game_pos = (monitor_resolution[0]/2, monitor_resolution[1]/2)
play_pos = (monitor_resolution[0]*.53, monitor_resolution[1]*.87)
folder_path = os.path.dirname(os.path.realpath(__file__))
AllSaves = folder_path + "\\AllSaves\\"
CurrentSave = folder_path + "\\CurrentSave\\"


def delete_all_saves():
    saves_list = os.listdir(saves_directory_path)
    for save in saves_list:
        if save.endswith(".sav"):
            os.remove(os.path.join(saves_directory_path, save))


def quit_current_game():
    kb.send('esc')
    time.sleep(menu_delay_seconds)
    pag.click(save_and_quit_pos)
    kb.send('esc')


def copy_savestate_to_directory():
    savestate_folder_contents = os.listdir(CurrentSave)
    try:
        shutil.copy(CurrentSave + savestate_folder_contents[0],  saves_directory_path + "\\savestate.sav")
    except IndexError:
        print("CurrentSave folder is empty, please insert save and reload script.")
        exit()


def load_savestate():
    if check_window():
        quit_current_game()
        time.sleep(load_delay_seconds)
        delete_all_saves()
        copy_savestate_to_directory()
        time.sleep(load_delay_seconds)
        pag.click(load_game_pos)
        time.sleep(menu_delay_seconds)
        pag.click(play_pos)


def create_savestate():
    if check_window():
        delete_all_saves()
        quit_current_game()
        time.sleep(load_delay_seconds)
        for item in os.listdir(CurrentSave):
            shutil.move(CurrentSave + item, AllSaves + item)
        for item in os.listdir(saves_directory_path):
            if item.endswith(".sav"):
                shutil.copy(saves_directory_path + "\\" + item, CurrentSave + "temp.sav")
                break
        time.sleep(load_delay_seconds)
        try:
            os.rename(CurrentSave + "temp.sav", CurrentSave + savestate_name_popup() + ".sav")
        except TypeError:
            print("Invalid name, please reload script.")


def savestate_name_popup():
    root = tk.Tk()
    root.withdraw()
    user_input = simpledialog.askstring(title="Enter Name", prompt="Name your savestate:")
    root.destroy()
    return user_input


def check_window():
    if pag.getActiveWindowTitle() == game_window_name:
        return True


def switch_active_savestate():  # this is the ugliest thing ive ever made i hate tkinter
    root = tk.Tk()
    root.geometry("200x220")
    root.attributes('-topmost', True)
    listbox = tk.Listbox(root)
    listbox.pack()
    for item in os.listdir(AllSaves):
        listbox.insert(tk.END, item)

    def button_clicked():  # lmao
        try:
            selection = listbox.curselection()[0]
        except IndexError:
            root.destroy()
            return
        file = listbox.get(selection)
        for save in os.listdir(CurrentSave):
            shutil.move(CurrentSave + save, AllSaves + save)
        shutil.move(AllSaves + file, CurrentSave + file)
        root.destroy()
        return
    button = tk.Button(root, text="Confirm", command=button_clicked)
    button.pack()
    root.mainloop()


kb.add_hotkey(savestate_create_hotkey, create_savestate)
kb.add_hotkey(savestate_load_hotkey, load_savestate)
kb.add_hotkey(savestate_switch_hotkey, switch_active_savestate)
kb.wait()

